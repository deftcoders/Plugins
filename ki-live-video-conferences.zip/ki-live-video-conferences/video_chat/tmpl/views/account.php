<?php
namespace KiLiveVideoConferences;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

?>
<div class="ki-live-video-conferences">
	<div class="">
		<a href="/members/" class="ki-but"><?php esc_html_e( 'Patients', 'ki-live-video-conferences' );?></a>
	</div>
</div>



