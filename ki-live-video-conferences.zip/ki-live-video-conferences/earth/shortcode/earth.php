<?php
?>

<div class="ki-earth-container">
	<canvas  class="ki-earth"></canvas>
</div>
