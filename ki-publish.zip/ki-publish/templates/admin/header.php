<link rel="stylesheet" href="<?=BASE_URL . 'assets/css/style.css'?>">
<link rel="stylesheet" href="<?=BASE_URL . 'assets/css/modal.css'?>">
<h2 class="sm-title">Sm-publish</h2>
<hr>