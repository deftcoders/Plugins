<?php ob_start();
global $wpdb;
$table_name = $wpdb->prefix . "options";
$ki_license_data   = $wpdb->get_results("SELECT * FROM $table_name WHERE option_name IN('ki_license_key', 'ki_license_status')");
if (!empty($_POST) ) {  
		$ki_license_status    = $_POST['ki_license_status'];
		if(!empty($_POST['license_key'])){
		$license_key    = $_POST['license_key'];
		$checkKey = validate_license($license_key);
			if($checkKey=="valid") {
				if (empty($ki_license_data)) {
					$wpdb->query("
						INSERT INTO $table_name (option_name, option_value, autoload)
						VALUES ('ki_license_key', '$license_key', 'yes'),
							   ('ki_license_status', '$ki_license_status', 'yes')
					");
					echo"<script>location.reload();</script>";
				} else {
					$wpdb->query("
						UPDATE $table_name 
						SET option_value='$license_key' 
						WHERE option_name='ki_license_key'
					");
					
					$wpdb->query("
						UPDATE $table_name 
						SET option_value='valid' 
						WHERE option_name='ki_license_status'
					");	
					echo"<script>location.reload();</script>";					
				}				
			} else {
				
				
				if (empty($ki_license_data)) {
					$wpdb->query("
						INSERT INTO $table_name (option_name, option_value, autoload)
						VALUES ('ki_license_key', '$license_key', 'yes'),
							   ('ki_license_status', '$ki_license_status', 'yes')
					");
					echo"<script>location.reload();</script>";
					
				} else {
					$wpdb->query("
						UPDATE $table_name 
						SET option_value='$license_key' 
						WHERE option_name='ki_license_key'
					");
					
					$wpdb->query("
						UPDATE $table_name 
						SET option_value='unvalid' 
						WHERE option_name='ki_license_status'
					");
					social_option();
					echo"<script>location.reload();</script>";
				}			
			}
		} 
		ob_flush();

	}
	
function validate_license($license_key){
	$response = wp_remote_get( "https://waelhassan.com/ki-api/validate-license.php?validate_license=$license_key" );
	if ( is_wp_error( $response ) ) {
	   echo 'There be errors, yo!';
	} else {
	   $body = wp_remote_retrieve_body( $response );
	   //$data = json_decode( $body );
	   return $body;
	}

	if ( $data->Data ) {
	   echo 'We got data, yo!';
	}
}

function social_option() {
	$wc_options = get_option('wc_options');
	$updateOptionArray = array();
	foreach(unserialize($wc_options) as $key=>$wc_val) {
		$updateOptionArray[$key]=$wc_val;
		if($key=="enableFbLogin") { $updateOptionArray[$key]=0; } if($key=="enableFbShare") { $updateOptionArray[$key]=0; }
		if($key=="enableTwitterLogin") { $updateOptionArray[$key]=0; } if($key=="enableTwitterShare") { $updateOptionArray[$key]=0; }
		if($key=="enableDisqusLogin") { $updateOptionArray[$key]=0; } if($key=="enableDisqusShare") { $updateOptionArray[$key]=0; }
		if($key=="enableGoogleLogin") { $updateOptionArray[$key]=0; } if($key=="enableGoogleShare") { $updateOptionArray[$key]=0; }
		if($key=="enableVkLogin") { $updateOptionArray[$key]=0; } if($key=="enableVkShare") { $updateOptionArray[$key]=0; }
		if($key=="enableStickButton") { $updateOptionArray[$key]=0; } if($key=="enableCloseButton") { $updateOptionArray[$key]=0; }	
	}	
	update_option( 'wc_options', serialize($updateOptionArray ));	
}
ob_clean();
ob_flush();
?></form>
<p class="full"><h2 class="sm-twitter-credentials">Activate Plugin License</h2></p>
<form class="sm-menu-container" method="post" action>
     <?php if($ki_license_data[1]->option_value=="unvalid") { echo "<p class='error'> Unvalid Key. Please enter valid Key.</p>"; } else { echo "<p class='success'> Activated.</p>";} ?> </p>
	<p class="half">
	<label for="consumer_vk_key">License Key:</label>
	<input type="hidden" name="form" value="license">
	<input type="text" id="license_key" name="license_key" value="<?php if(!empty($ki_license_data)){ echo $ki_license_data[0]->option_value; } ?>"></p>
	<p class="half">
		<input type="submit" name="submit" id="submit" class="button button-primary" value="Save Changes">
	</p>
</form>

<style> input[name="wc_submit_options"] { display: none !important; } .sm-menu-container p.error { color:red; } .sm-menu-container p.success{ color:green; } </style>