<div class="stream" style=" background:#f3f3f3">
<div class="stream-header">
    
</div>
<div class="stream-content">
    <img src="<?=BASE_URL?>images/buttons/icon-calender.png" alt="">
    <p class="empty-message">No created tabs right now<br>Please Add new tab</p>
    <button class="btn-blue" data-modal='openModal' data-type='add-tab'>Add tab</button>
</div>
</div>
<script data-id="ki-publish" src="<?=BASE_URL?>assets/js/modal.js"></script>