<div class="stream" style=" background:#f3f3f3">
<div class="stream-header users-header">
	<div class="users-data">
		
	</div>
	<div class="right-button-group">
		<button class="btn btn-pink" data-modal='openModal' data-type='add-team'>
			<img src="<?=BASE_URL?>images/buttons/icon-plus.png" class="cm-mr-3">Add team
		</button>
	</div>
</div>
<div class="stream-content">
    <img src="<?=BASE_URL?>images/buttons/icon-calender.png" alt="">
    <p class="empty-message">No Teams right now<br>Please Add new Team</p>
    <button class="btn-blue" data-modal='openModal' data-type='add-team'>Add tab</button>
</div>
</div>
<script data-id="ki-publish" src="<?=BASE_URL?>assets/js/modal.js"></script>