<div class="stream" style=" background:#f3f3f3">
<div class="stream-header">
    <ul class="assigned-menu">
    	<li>Assigned messages to me</li>
    	<li>Assigned messages by me</li>
    	<li>Assigned streams</li>
    	<li>Assigned teams</li>
    </ul>
</div>
<div class="stream-content">
    <img src="<?=BASE_URL?>images/buttons/group-4@3x.png" alt="">
    <p class="empty-message">No assigned messages<br>right now</p>
</div>
</div>
<script data-id="ki-publish" src="<?=BASE_URL?>assets/js/modal.js"></script>