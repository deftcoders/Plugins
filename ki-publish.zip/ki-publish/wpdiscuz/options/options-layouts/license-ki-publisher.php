<?php if (!defined('ABSPATH')) { exit();} ?> <div><?php 
if($_GET['ki_publisher_tab']==12){
include_once(WP_CONTENT_DIR . '/plugins/ki-publish/templates/admin/license_content.php'); } ?>
</div>