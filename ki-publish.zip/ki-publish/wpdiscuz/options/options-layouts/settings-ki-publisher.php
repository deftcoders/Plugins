<?php if (!defined('ABSPATH')) { exit();} ?> <div><?php 
if($_GET['ki_publisher_tab']==9){
include_once(WP_CONTENT_DIR . '/plugins/ki-publish/templates/admin/content.php'); } ?>
</div>