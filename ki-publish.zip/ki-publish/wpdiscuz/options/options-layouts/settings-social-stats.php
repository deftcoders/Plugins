<?php
if (!defined('ABSPATH')) {
    exit();
}
?>
<div>
    <h2 class="wpd-subtitle"><?php _e('Social Login &amp; Share', 'wpdiscuz'); ?> </h2>
    <p class="wpd-subtitle"> Comming soon </p>
</div>