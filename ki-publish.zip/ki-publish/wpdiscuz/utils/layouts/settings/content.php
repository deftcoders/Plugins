<?php
if (!defined('ABSPATH')) {
    exit();
}
ob_start();
global $current_user;
?>
<div class="container update_profile_container">
<form name="update_profile" method="POST" action="">
	<div class="row">
          <div class="form-group">
            <label class="col-md-3 control-label">First Name:</label>
            <div class="col-md-8">
              <input class="form-control" type="text" name ="user_firstname"value="<?php if(!empty($current_user->user_firstname)) { echo $current_user->user_firstname; } ?>">
            </div>
          </div>
          <div class="form-group">
            <label class="col-md-3 control-label">Last Name:</label>
            <div class="col-md-8">
              <input class="form-control" type="text" name ="user_lastname" value="<?php if(!empty($current_user->user_lastname)) { echo $current_user->user_lastname; } ?>">
            </div>
          </div>
		  
          <div class="form-group">
            <label class="col-md-3 control-label">Email:</label>
            <div class="col-md-8">
              <input class="form-control" type="email" name ="email" value="<?php if(!empty($current_user->user_email)) { echo $current_user->user_email; } ?>">
            </div>
          </div>
		  
          <div class="form-group">
            <label class="col-md-3 control-label">Password:</label>
            <div class="col-md-8">
              <input class="form-control" type="password" name ="password" value="">
            </div>
          </div>		  
          <div class="form-group submitbtn-container">
            <label class="col-md-3 control-label"></label>
            <div class="col-md-8">
              <input type="submit" name ="profile_submit" value="Save Changes">
              <span></span>
              <input type="reset" class="btn btn-default" value="Cancel">
            </div>
          </div>
       
      </div>
	   </form>
  </div>

<?php $html .= ob_get_clean();
