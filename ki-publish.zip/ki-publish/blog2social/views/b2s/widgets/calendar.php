<div class="b2s-widget-calendar"></div>
<script>
    var b2s_calendar_locale = '<?= strtolower(substr(get_locale(), 0, 2)); ?>';
    var b2s_plugin_url = '<?= B2S_PLUGIN_URL; ?>';
</script>