<?php 
namespace SocialMedia\template;

class Template {

	public $dir;

	public function __construct($dir)
	{
		$this->dir = $dir;
	}

	public function createBase()
	{	
		require $this->dir . 'templates/base.php';
		require $this->dir . 'templates/modals.php';	
	}

	public function createStream()
	{
		require $this->dir . 'templates/stream.php';
	}

	public function createCalendar()
	{
		require $this->dir . 'templates/calendar.php';
	}

	public function createUsers()
	{
		require $this->dir . 'templates/users.php';
	}

	public function createAssignments()
	{
		require $this->dir . 'templates/assignments.php';	
	}

	public function createSmartContent()
	{
		require $this->dir . 'templates/smart-content.php';	
	}

	public function createLogin()
	{
		require $this->dir . 'templates/login.php';	
	}

	public function createFollowers()
	{
		require $this->dir . 'templates/followers.php';	
	}
}


