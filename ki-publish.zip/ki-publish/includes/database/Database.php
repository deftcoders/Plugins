<?php 
namespace SocialMedia\database;

class Database {

	public function createTables() 
	{

		global $wpdb;
		$table_name = $wpdb->prefix . "sm_users"; 
		$result = $wpdb->query("SELECT * 
                FROM INFORMATION_SCHEMA.TABLES 
                WHERE TABLE_SCHEMA = '" . $wpdb->dbname . "' 
                AND  TABLE_NAME = '" . $table_name . "'
		");

		if (!$result) {
			$user_table_query = $wpdb->query(
				"CREATE TABLE `$table_name` (
			     `id` int(11) NOT NULL AUTO_INCREMENT,
			     `oauth_provider` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
			     `twitter_oauth` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
			     `oauth_uid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
			     `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
			     `fname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
			     `lname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
			     `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
			     `locale` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
			     `oauth_token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
			     `oauth_secret` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
			     `picture` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
			     `created` datetime NOT NULL,
			     `modified` datetime NOT NULL,
			     `level` int(2) NOT NULL DEFAULT 0,
			     `followers_count` int(11) NOT NULL DEFAULT 0,
			     `friends_count` int(11) NOT NULL DEFAULT 0,
			     `statuses_count` int(11) NOT NULL DEFAULT 0,
			     `allow_public_chat` int(1) NOT NULL DEFAULT 0,
			     `allow_notify_followers` int(1) NOT NULL DEFAULT 0,
			     `disconnected` int(1) NOT NULL DEFAULT 0,
			     PRIMARY KEY (`id`)
			    ) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;"
			);

			$table_name = $wpdb->prefix . "buffer_profile_users"; 

			$user_table_query = $wpdb->query(
				"CREATE TABLE `$table_name` (
				  `id` int(11) NOT NULL AUTO_INCREMENT,
				  `userId` varchar(255) DEFAULT NULL,
				  `profileId` varchar(255) DEFAULT NULL,
				  `serviceName` varchar(255) DEFAULT NULL,
				  `serviceId` varchar(255) DEFAULT NULL,
				  `status` varchar(255) DEFAULT NULL,
				  `twitUserId` varchar(255) DEFAULT NULL,
				  PRIMARY KEY (`id`)
				) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8;"
			);

			$table_name = $wpdb->prefix . "hootsuite_profile_users"; 

			$user_table_query = $wpdb->query(
				"CREATE TABLE `$table_name` (
				  `id` int(11) NOT NULL AUTO_INCREMENT,
				  `userId` varchar(255) DEFAULT NULL,
				  `profileId` varchar(255) DEFAULT NULL,
				  `serviceName` varchar(255) DEFAULT NULL,
				  `serviceId` varchar(255) DEFAULT NULL,
				  `profileUname` varchar(255) DEFAULT NULL,
				  `twitUserId` varchar(255) DEFAULT NULL,
				  PRIMARY KEY (`id`)
				) ENGINE=InnoDB DEFAULT CHARSET=utf8;"
			);


		}
	}
}

