<?php 
session_start();

use SmFunctions\hootsuiteoauth\HootsuiteOAuth;
use SmFunctions\linkedinoauth\LinkedinOAuth;
use SmFunctions\twitteroauth\TwitterOAuth;
use SmFunctions\bufferoauth\BufferOAuth;
use SmFunctions\sysomos\Sysomos;
use SmFunctions\vk\Vk;

class Actions {
	public $oauth_token_secret;
	public $consumer_secret;
	public $consumer_key;
	public $callback_url;
	public $hootsuiteAPI;
	public $oauth_token;
	public $linkedinAPI;
	public $twitterAPI;
	public $bufferAPI;
	public $base_url;
	public $site_url;
	public $user_id;
	public $sysomos;
	public $vk;
	public $db;

	public function __construct()
	{
		$this->get_configs();
		$this->set_consumer_data();
		$this->set_oauth_data();

		$this->hootsuiteAPI = new HootsuiteOAuth();
		$this->twitterAPI = new TwitterOAuth($this->consumer_key, $this->consumer_secret, $this->oauth_token, $this->oauth_token_secret);
		$this->linkedinAPI = new LinkedinOAuth();
		$this->bufferAPI = new BufferOAuth();
		$this->sysomos = new Sysomos();
		$this->vk = new Vk();


		if (isset($_POST['action'])) {
			if (method_exists($this, $_POST['action'])) {
				call_user_func(array($this, $_POST['action']), $this->decodeJson($_POST['data']));
			}
		} else {
			if (!isset($_POST['vk_hash'])) {
				$this->check_hash();
			} else if (isset($_POST['vk_hash'])) {
				$this->get_vk_user($_POST);
			}
		}

		if($_GET['vk']) { $this->vk_auth(); }
		if($_GET['buffer']) { $this->buffer_auth(); }
		if($_GET['twitter']) { $this->twitter_auth(); }
		if($_GET['linkedin']) { $this->linkedin_auth(); }
		if($_GET['hootsuite']) { $this->hootsuite_auth(); }
		if(isset($_GET['state']) && isset($_GET['code']) && !isset($_GET['scope'])) { $this->get_buffer_token(); }
		if(isset($_GET['oauth_token']) && isset($_GET['oauth_verifier'])) { $this->set_twitter_data(); }
		if(isset($_GET['code']) && count($_GET) == 1) { $this->get_linkedin_token(); }
		if(isset($_GET['expires_in']) && isset($_GET['user_id'])) { $this->get_vk_user(); }
		if(isset($_GET['code']) && isset($_GET['scope']) && isset($_GET['state']) && $_GET['scope'] == 'offline') { $this->get_hootsuite_access_token(); }
	}

	public function check_hash()
	{
		?>
		<form action="" id="hash" method="post">
			<input name="vk_hash" value="window.location.hash" type="hidden">
		</form>
		<script>
			if(window.location.hash) {
				var form = document.getElementById('hash')
				form.children[0].value = window.location.hash;
				form.submit()
			}
		</script>
		<?php
	}


	public function updateStatusesCount($post_status)
	{	
		global $wpdb;

		$table_name = $wpdb->prefix."sm_users";
		$user = $post_status->user;

		$user_id = isset($user->id) ? $user->id : 0 ;
		$statuses_count = isset($user->statuses_count) ? $user->statuses_count : 0 ;

		$user_info = $wpdb->get_results("SELECT * FROM $table_name WHERE oauth_provider = 'twitter' AND oauth_uid = '$user_id'");

		if (!empty($user_info)) {
			
			$wpdb->update($table_name, array('statuses_count'=>$statuses_count), array('oauth_provider'=>'twitter','oauth_uid' => $user_id ));

		}

	}

	public function showToken($data)
	{
		print_r($_SESSION);
	}

	public function decodeJson($json)
	{
		return json_decode(stripslashes($json));
	}

	public function get_all_linkedin_posts($data)
	{
		echo json_encode($this->linkedinAPI->getPosts());
	}

	public function linkedin_auth()
	{
		header('Location:' . $this->linkedinAPI->getLinkedinAuthUrl());
	}

	public function get_linkedin_token()
	{
		$res = $this->linkedinAPI->getAccessToken($_GET['code']);
		$_SESSION['linkedin_access_token'] = $res->access_token;
		$this->set_linkedin_user_data();
	}

	public function set_linkedin_user_data()
	{
		$key       = '';
		$user_info = $this->linkedinAPI->getUserInfo();

		foreach ($user_info->firstName->localized as $k => $value) {$key = $k;}

		$data = [];
		$data['oauth_provider'] = 'linkedin';
		$data['twitter_oauth'] = $_SESSION['request_vars']['user_id'];
		$data['oauth_uid'] = $user_info->id;
		$data['username'] = $user_info->firstName->localized->{$key} . ' ' . $user_info->lastName->localized->{$key};
		$data['fname'] = $user_info->firstName->localized->{$key};
		$data['lname'] = $user_info->lastName->localized->{$key};
		$data['email'] = isset($user_info->email) ? $user_info->email : '';
		$data['locale'] = $user_info->firstName->preferredLocale->language;
		$data['oauth_token'] = $_SESSION['linkedin_access_token'];
		$data['oauth_secret'] = '';
		$data['picture'] = $user_info->profilePicture->{'displayImage~'}->elements[2]->identifiers[0]->identifier;
		$data['created'] = date("Y-m-d H:i:s");
		$data['modified'] = date("Y-m-d H:i:s");
		$data['level'] = '0';
		$data['followers_count'] = '0';
		$data['friends_count'] = '0';
		$data['statuses_count'] = '0';
		$data['allow_public_chat'] = '0';
		$data['allow_notify_followers'] = '0';
		$data['disconnected'] = '0';

		$this->linkedinAPI->checkUser($data);

		$_SESSION['linkedin_user'] = $data;
		header("Location: $this->site_url");

	}

	public function add_linkedin_post($data)
	{
		$this->linkedinAPI->addPost($data);
	}

	public function twitter_auth()
	{
		$connection = new TwitterOAuth($this->consumer_key, $this->consumer_secret);
		$request_token = $connection->getRequestToken($this->callback_url);

	    $fp = fopen('lidn.txt', 'w');
		fwrite($fp, $request_token['oauth_token'] . ';');
		fwrite($fp, $request_token['oauth_token_secret'] . ';');
		fwrite($fp, $_GET['url'] . ';');
		fclose($fp);

		$twitter_url = $connection->getAuthorizeURL($request_token['oauth_token']);
		header("Location: $twitter_url");
	}

	public function set_twitter_data()
	{
		global $wpdb;

		$fh   = fopen('lidn.txt', 'r');
		$line = explode(';', fgets($fh));

		$connection   = new TwitterOAuth($this->consumer_key, $this->consumer_secret, $line[0] , $line[1]);
	    $access_token = $connection->getAccessToken($_GET['oauth_verifier']);

		$user_info  = $connection->get('account/verify_credentials', array('include_email' => 'true'));
		$table_name = $wpdb->prefix . "sm_users";

		$user_info->lang = empty($user_info->extended_entities->lang) ? 'en' : $user_info->extended_entities->lang;

		$name  = explode(" ",$user_info->name);
	    $fname = isset($name[0])?$name[0]:'';
	    $lname = isset($name[1])?$name[1]:'';

	    property_exists($user_info, 'email') ? $user_info->email = $user_info->email : $user_info->email = '';

		$data = [];
		$data['oauth_provider'] = 'twitter';
		$data['oauth_uid'] = $user_info->id;
		$data['username'] = $user_info->screen_name;
		$data['fname'] = $fname;
		$data['lname'] = $lname;
		$data['email'] = $user_info->email;
		$data['locale'] = $user_info->lang;
		$data['oauth_token'] = $access_token['oauth_token'];
		$data['oauth_secret'] = $access_token['oauth_token_secret'];
		$data['picture'] = $user_info->profile_image_url;
		$data['created'] = date("Y-m-d H:i:s");
		$data['modified'] = date("Y-m-d H:i:s");
		$data['level'] = '0';
		$data['followers_count'] = $user_info->followers_count;
		$data['friends_count'] = $user_info->friends_count;
		$data['statuses_count'] = $user_info->statuses_count;
		$data['allow_public_chat'] = '0';
		$data['allow_notify_followers'] = '0';
		$data['disconnected'] = '0';

		$res = $wpdb->get_results("SELECT * FROM $table_name WHERE oauth_provider = 'twitter' AND oauth_uid = '$user_info->id'");
		if (empty($res)) {
			$res = $wpdb->insert($table_name, $data);
		} else {
			$where = array('oauth_provider' => 'twitter', 'oauth_uid' => $data['oauth_uid']);
			$res = $wpdb->update($table_name, $data, $where);
		}
		$_SESSION['status'] = 'verified';
	    $_SESSION['request_vars']['screen_name'] = $data['username'];
	    $_SESSION['request_vars']['user_id'] = $data['oauth_uid'];
	    $_SESSION['request_vars']['oauth_token'] = $data['oauth_token'];
	    $_SESSION['request_vars']['oauth_token_secret'] = $data['oauth_secret'];
	    $_SESSION['request_vars']['picture'] = $data['picture'];
	    $_SESSION['request_vars']['followers'] = $data['followers_count'];
	    $_SESSION['request_vars']['friends_count'] = $data['friends_count'];
	    $_SESSION['request_vars']['statuses_count'] = $data['statuses_count'];
	    $_SESSION['username'] = $data['fname'];

	    header('Location: /ki-publish-stream');
	}

	public function add_twitter_post($data)
	{
		$media_info = $this->twitterAPI->post('media/upload', array('media_data' => base64_encode( file_get_contents($data->tPhoto) ) ), 1);

		$status_arr = array(
		    'status' => $data->tPost,
		    'in_reply_to_status_id' => ''
		);

		if(isset($media_info->media_id)){
        	$status_arr['media_ids'] = $media_info->media_id;
		}

	    $res = $this->twitterAPI->post('statuses/update', $status_arr);
	    echo json_encode($res);
	}

	public function get_all_twitter_posts($data)
	{
		$res = $this->twitterAPI->get('statuses/user_timeline', array('user_id' => $_SESSION['request_vars']['user_id']));
		echo json_encode($res);
	}

	public function get_twitter_updates($data)
	{
		$res = $this->twitterAPI->get('statuses/lookup', array('id' => implode(',', $data)));
		echo json_encode($res);
	}

	public function get_tw_followers($data)
	{
		$res = $this->twitterAPI->get('followers/list', array('user_id' => $_SESSION['request_vars']['user_id']));
		
		// if(isset($res->users)) {
		// 	foreach ($res->users as $value) {
		// 		$users .= $value->screen_name;
		// 	}
		// 	$res = $this->sysomos->get_tw_user_location($users);
		// }

		
		echo json_encode($res);
	}

	public function get_tw_locations()
	{
		$res = $this->twitterAPI->get('geo/search', array('query' => 'Egypt'));
		echo json_encode($res);
	}

	public function buffer_auth()
	{
		header("Location:" . $this->bufferAPI->getBufferAuthUrl());

	}

	public function delete_buffer_account()
	{
		$this->bufferAPI->removeBufferAccount();
	}

	public function get_buffer_profiles()
	{
		echo json_encode($this->bufferAPI->selectProfilesData());
	}

	public function get_all_buffer_posts($data)
	{
		$profile_id = $data->prID;
		echo json_encode($this->bufferAPI->getProfilePosts($profile_id, $_SESSION['buffer_access_token']));
	}

	public function get_buffer_updates($data)
	{
		$updates = [];

		foreach ($data as $value) {
			$updates[] = $this->bufferAPI->getProfilePostsData($value, $_SESSION['buffer_access_token']);
		}

		echo json_encode($updates);
	}

	public function add_buffer_post($data)
	{
		$result = $this->bufferAPI->addPost($data->bProfile, $_SESSION['buffer_access_token'], $data->bPost, $data->bMedia, $data->bPhoto);
		echo json_encode($result);
	}

	public function get_buffer_token()
	{
		$result = $this->bufferAPI->getAccessToken($_GET['code']);
		$_SESSION['buffer_access_token'] = $result->access_token;
		$userData = $this->bufferAPI->getUserData($_SESSION['buffer_access_token']);
		$this->set_buffer_user_data($userData);

	}

	public function set_buffer_user_data($userData)
	{
		$userInfo        = new stdClass();
		$userInfo->id    = $userData->id;
		$userInfo->twId  = $_SESSION['request_vars']['user_id'];
		$userInfo->name  = $userData->name;
		$userInfo->fname = explode(' ', $userInfo->name)[0];
		$userInfo->lname = explode(' ', $userInfo->name)[1];
		$userInfo->email = '';
		$userInfo->image = '';

		$results = $this->bufferAPI->getProfileData($_SESSION['buffer_access_token']);
		$data    = [];

		foreach ($results as  $result) {
			if ($userInfo->image == '' && $result->avatar != '') { $userInfo->image = $result->avatar; }

			$profileInfo = new stdClass();
			$profileInfo->uid     = $userInfo->id;
			$profileInfo->id      = $result->id;
			$profileInfo->service = $result->service;
			$profileInfo->sid     = $result->service_id;
			$profileInfo->status  = 1;
			$profileInfo->twid    = $userInfo->twId;

			array_push($data, $profileInfo);
		}

		$_SESSION['buffer_user'] = $userInfo;

		$user_data = $this->bufferAPI->checkUser(
			'buffer',
			$userInfo->twId,
			$userInfo->id,
			$userInfo->name,
			$userInfo->fname,
			$userInfo->lname,
			$userInfo->email,
			$userInfo->lang,
			$_SESSION['buffer_access_token'],
			'',
			$userInfo->image,
			'0',
			'0',
			'0'
		);

		$this->bufferAPI->checkProfiles($data);
		header("Location: $this->site_url");
	}

	public function add_user($data)
	{

		$data = json_decode(stripslashes($data['data']));
		$media_info = $this->twitterAPI->post('media/upload', array('media_data' => base64_encode(file_get_contents($data->image))), 1);
		$status_arr = array(
		    'status' => $data->status,
		    'media_ids' => $media_info->media_id,
		    'in_reply_to_status_id' => ''
		);
		
		$post_status = $this->twitterAPI->post('statuses/update', $status_arr);

		$this->updateStatusesCount($post_status);


		if (isset($post_status->id)) {
			 return array('message'=>'Tweet posted successfully.', 'error' => 0)  ;
		}else{
			 return json_encode( array('message'=>'Tweet posting error.Please try again', 'error' => 1) ) ;
		}
	}

	private function get_configs()
	{
		include $_SERVER['CONTEXT_DOCUMENT_ROOT'].'/wp-config.php';
		include $_SERVER['CONTEXT_DOCUMENT_ROOT'].'/wp-load.php';
	}

	private function set_consumer_data()
	{
		global $wpdb;

		$table_name = $wpdb->prefix . 'options';
		$consumerdata = $wpdb->get_results("
						SELECT option_value FROM $table_name
						WHERE option_name 
						IN ('sm_twitter_consumer_key', 'sm_twitter_consumer_secret', 'sm_twitter_redirect_url')");

		$this->consumer_key    = $consumerdata[0]->option_value;
		$this->consumer_secret = $consumerdata[1]->option_value;
		$this->callback_url    = $consumerdata[2]->option_value;
	}

	private function set_oauth_data()
	{
		$this->user_id      	  = $_SESSION['request_vars']['user_id'];
		$this->oauth_token  	  = $_SESSION['request_vars']['oauth_token'];
		$this->oauth_token_secret = $_SESSION['request_vars']['oauth_token_secret'];

		$this->site_url = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . '/ki-publish-stream/';
	}

	public function removeBufferAccount()
	{
		$this->bufferAPI->removeBufferAccount();
	}

	public function vk_auth()
	{
		header('Location:' . $this->vk->getVkAuthUrl());
	}

	public function get_vk_user($data)
	{
		preg_match('/#access_token=([A-z0-9]+)&expires_in=([A-z0-9]+)&user_id=([A-z0-9]+)/', $data['vk_hash'], $data);
		$_SESSION['vk_access_token'] = $data[1];

		$user_info = $this->vk->get_user_info($data[3], $data[1])->response[0];

		$data = [];
		$data['oauth_provider'] = 'vk';
		$data['twitter_oauth'] = $_SESSION['request_vars']['user_id'];
		$data['oauth_uid'] = $user_info->id;
		$data['username'] = $user_info->first_name . ' ' . $user_info->last_name;
		$data['fname'] = $user_info->first_name;
		$data['lname'] = $user_info->last_name;
		$data['email'] = isset($user_info->email) ? $user_info->email : '';
		$data['locale'] = isset($user_info->lang) ? $user_info->lang : '';
		$data['oauth_token'] = $_SESSION['vk_access_token'];
		$data['oauth_secret'] = '';
		$data['picture'] = $user_info->photo;
		$data['created'] = date("Y-m-d H:i:s");
		$data['modified'] = date("Y-m-d H:i:s");
		$data['level'] = '0';
		$data['followers_count'] = '0';
		$data['friends_count'] = $user_info->common_count;
		$data['statuses_count'] = '0';
		$data['allow_public_chat'] = '0';
		$data['allow_notify_followers'] = '0';
		$data['disconnected'] = '0';

		$this->vk->checkUser($data);

		$_SESSION['vk_user'] = $data;
		header("Location: $this->site_url");
	}

	public function get_all_vk_posts($data)
	{
		$res = $this->vk->get_all_posts($_SESSION['vk_user']['oauth_uid']);
		echo json_encode($res->response->items);
	}

	public function add_vk_post($data)
	{
		$res = $this->vk->add_post($_SESSION['vk_user']['oauth_uid'], $data);

		echo json_encode($res);
	}

	public function hootsuite_auth()
	{
		header('Location:' . $this->hootsuiteAPI->getHoostsuiteAuthUrl());
	}

	public function get_hootsuite_access_token()
	{
		$access_token = $this->hootsuiteAPI->getAccessToken($_GET['code']);

		$_SESSION['hootsuite_access_token'] = $access_token->access_token;

		$this->get_hootsuite_user($access_token->access_token);
	}

	public function get_hootsuite_user($access_token)
	{
		$res = $this->hootsuiteAPI->getUserData($access_token);

		$user_data = $this->hootsuiteAPI->checkUser(
			'hootsuite',
			$_SESSION['request_vars']['user_id'],
			$res->data->id,
			$res->data->fullName,
			$res->data->fullName,
			'',
			$res->data->email,
			$res->data->language,
			$access_token,
			'',
			'',
			'0',
			'0',
			'0'
		);

		$_SESSION['hootsuite_user'] = $user_data;

		$profiles = $this->hootsuiteAPI->getProfileData();
		$profiles = $profiles->data;

		$this->hootsuiteAPI->checkProfiles($profiles, $user_data['twitter_oauth']);
		header("Location: $this->site_url");
	}

	public function add_hootsuite_post($data)
	{
		$res = $this->hootsuiteAPI->addPost($data->hProfile, $data->hPost, $data->hPhoto);
		
		echo json_encode($res);
	}

	public function get_hootsuite_profiles($data)
	{
		echo json_encode($this->hootsuiteAPI->selectProfilesData());
	}

	public function get_all_hootsuite_posts($data)
	{
		echo json_encode($this->hootsuiteAPI->getProfilePosts($data->profileId));
	}

}

$actions = new Actions();