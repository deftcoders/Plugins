<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://waelhassan.com
 * @since      1.0.0
 *
 * @package    Ki_inbox
 * @subpackage Ki_inbox/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Ki_inbox
 * @subpackage Ki_inbox/includes
 * @author     wael hassan wael.hassan@gmail.com
 */
//namespace KiTwitterAnalytics;

class Ki_inbox_Deactivator
{

    /**
     * Short Description. (use period)
     *
     * Long Description.
     *
     * @since    1.0.0
     */
    public static function deactivate()
    {

    }

}
