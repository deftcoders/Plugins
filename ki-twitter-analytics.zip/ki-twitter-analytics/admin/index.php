<?php // Silence is golden
namespace KiTwitterAnalytics;